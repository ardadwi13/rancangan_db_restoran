--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.uuser DROP CONSTRAINT uuser_pkey;
ALTER TABLE ONLY public.transaksi DROP CONSTRAINT transaksi_pkey;
ALTER TABLE ONLY public.penumpang DROP CONSTRAINT penumpang_pkey;
ALTER TABLE ONLY public.oorder DROP CONSTRAINT oorder_pkey;
ALTER TABLE ONLY public.masakan DROP CONSTRAINT masakan_pkey;
ALTER TABLE ONLY public.levell DROP CONSTRAINT levell_pkey;
ALTER TABLE ONLY public.detail_order DROP CONSTRAINT detail_order_pkey;
ALTER TABLE public.uuser ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.uuser ALTER COLUMN id_user DROP DEFAULT;
ALTER TABLE public.transaksi ALTER COLUMN id_transaksi DROP DEFAULT;
ALTER TABLE public.penumpang ALTER COLUMN id_penumpang DROP DEFAULT;
ALTER TABLE public.oorder ALTER COLUMN id_user DROP DEFAULT;
ALTER TABLE public.oorder ALTER COLUMN id_order DROP DEFAULT;
ALTER TABLE public.masakan ALTER COLUMN id_masakan DROP DEFAULT;
ALTER TABLE public.levell ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.detail_order ALTER COLUMN id_masakan DROP DEFAULT;
ALTER TABLE public.detail_order ALTER COLUMN id_order DROP DEFAULT;
ALTER TABLE public.detail_order ALTER COLUMN id_detail_order DROP DEFAULT;
DROP SEQUENCE public.uuser_id_user_seq;
DROP SEQUENCE public.uuser_id_level_seq;
DROP TABLE public.uuser;
DROP SEQUENCE public.transaksi_id_transaksi_seq;
DROP TABLE public.transaksi;
DROP SEQUENCE public.penumpang_id_penumpang_seq;
DROP TABLE public.penumpang;
DROP SEQUENCE public.oorder_id_user_seq;
DROP SEQUENCE public.oorder_id_order_seq;
DROP TABLE public.oorder;
DROP SEQUENCE public.masakan_id_masakan_seq;
DROP TABLE public.masakan;
DROP SEQUENCE public.levell_id_level_seq;
DROP TABLE public.levell;
DROP SEQUENCE public.detail_order_id_order_seq;
DROP SEQUENCE public.detail_order_id_masakan_seq;
DROP SEQUENCE public.detail_order_id_detail_order_seq;
DROP TABLE public.detail_order;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_order (
    id_detail_order integer NOT NULL,
    id_order integer NOT NULL,
    id_masakan integer NOT NULL,
    keterangan character varying(255),
    status_detail_order character varying(2)
);


ALTER TABLE detail_order OWNER TO postgres;

--
-- Name: detail_order_id_detail_order_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE detail_order_id_detail_order_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detail_order_id_detail_order_seq OWNER TO postgres;

--
-- Name: detail_order_id_detail_order_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE detail_order_id_detail_order_seq OWNED BY detail_order.id_detail_order;


--
-- Name: detail_order_id_masakan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE detail_order_id_masakan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detail_order_id_masakan_seq OWNER TO postgres;

--
-- Name: detail_order_id_masakan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE detail_order_id_masakan_seq OWNED BY detail_order.id_masakan;


--
-- Name: detail_order_id_order_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE detail_order_id_order_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detail_order_id_order_seq OWNER TO postgres;

--
-- Name: detail_order_id_order_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE detail_order_id_order_seq OWNED BY detail_order.id_order;


--
-- Name: levell; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE levell (
    id_level integer NOT NULL,
    nama_level character varying(100)
);


ALTER TABLE levell OWNER TO postgres;

--
-- Name: levell_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE levell_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE levell_id_level_seq OWNER TO postgres;

--
-- Name: levell_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE levell_id_level_seq OWNED BY levell.id_level;


--
-- Name: masakan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE masakan (
    id_masakan integer NOT NULL,
    nama_makanan character varying(100),
    harga integer,
    status_masakan character varying(2)
);


ALTER TABLE masakan OWNER TO postgres;

--
-- Name: masakan_id_masakan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE masakan_id_masakan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE masakan_id_masakan_seq OWNER TO postgres;

--
-- Name: masakan_id_masakan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE masakan_id_masakan_seq OWNED BY masakan.id_masakan;


--
-- Name: oorder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE oorder (
    id_order integer NOT NULL,
    no_meja integer,
    tanggal date,
    id_user integer NOT NULL,
    keterangan character varying(255),
    status_order character varying(2)
);


ALTER TABLE oorder OWNER TO postgres;

--
-- Name: oorder_id_order_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE oorder_id_order_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE oorder_id_order_seq OWNER TO postgres;

--
-- Name: oorder_id_order_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE oorder_id_order_seq OWNED BY oorder.id_order;


--
-- Name: oorder_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE oorder_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE oorder_id_user_seq OWNER TO postgres;

--
-- Name: oorder_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE oorder_id_user_seq OWNED BY oorder.id_user;


--
-- Name: penumpang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE penumpang (
    id_penumpang integer NOT NULL,
    username character varying(100),
    passsword character varying(100),
    nama_penumpang character varying(50),
    alamat_penumpang text,
    tanggal_lahir date,
    jenis_kelamin character(2),
    telefone character varying(12)
);


ALTER TABLE penumpang OWNER TO postgres;

--
-- Name: penumpang_id_penumpang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE penumpang_id_penumpang_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE penumpang_id_penumpang_seq OWNER TO postgres;

--
-- Name: penumpang_id_penumpang_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE penumpang_id_penumpang_seq OWNED BY penumpang.id_penumpang;


--
-- Name: transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE transaksi (
    id_transaksi integer NOT NULL,
    id_user integer,
    id_order integer,
    tanggal date,
    total_bayar integer
);


ALTER TABLE transaksi OWNER TO postgres;

--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE transaksi_id_transaksi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE transaksi_id_transaksi_seq OWNER TO postgres;

--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE transaksi_id_transaksi_seq OWNED BY transaksi.id_transaksi;


--
-- Name: uuser; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE uuser (
    id_user integer NOT NULL,
    username character varying(100),
    passsword character varying(100),
    nama_user character varying(100),
    id_level integer NOT NULL
);


ALTER TABLE uuser OWNER TO postgres;

--
-- Name: uuser_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE uuser_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE uuser_id_level_seq OWNER TO postgres;

--
-- Name: uuser_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE uuser_id_level_seq OWNED BY uuser.id_level;


--
-- Name: uuser_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE uuser_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE uuser_id_user_seq OWNER TO postgres;

--
-- Name: uuser_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE uuser_id_user_seq OWNED BY uuser.id_user;


--
-- Name: detail_order id_detail_order; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_order ALTER COLUMN id_detail_order SET DEFAULT nextval('detail_order_id_detail_order_seq'::regclass);


--
-- Name: detail_order id_order; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_order ALTER COLUMN id_order SET DEFAULT nextval('detail_order_id_order_seq'::regclass);


--
-- Name: detail_order id_masakan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_order ALTER COLUMN id_masakan SET DEFAULT nextval('detail_order_id_masakan_seq'::regclass);


--
-- Name: levell id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY levell ALTER COLUMN id_level SET DEFAULT nextval('levell_id_level_seq'::regclass);


--
-- Name: masakan id_masakan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY masakan ALTER COLUMN id_masakan SET DEFAULT nextval('masakan_id_masakan_seq'::regclass);


--
-- Name: oorder id_order; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY oorder ALTER COLUMN id_order SET DEFAULT nextval('oorder_id_order_seq'::regclass);


--
-- Name: oorder id_user; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY oorder ALTER COLUMN id_user SET DEFAULT nextval('oorder_id_user_seq'::regclass);


--
-- Name: penumpang id_penumpang; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penumpang ALTER COLUMN id_penumpang SET DEFAULT nextval('penumpang_id_penumpang_seq'::regclass);


--
-- Name: transaksi id_transaksi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transaksi ALTER COLUMN id_transaksi SET DEFAULT nextval('transaksi_id_transaksi_seq'::regclass);


--
-- Name: uuser id_user; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY uuser ALTER COLUMN id_user SET DEFAULT nextval('uuser_id_user_seq'::regclass);


--
-- Name: uuser id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY uuser ALTER COLUMN id_level SET DEFAULT nextval('uuser_id_level_seq'::regclass);


--
-- Data for Name: detail_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM stdin;
\.
COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM '$$PATH$$/2874.dat';

--
-- Data for Name: levell; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY levell (id_level, nama_level) FROM stdin;
\.
COPY levell (id_level, nama_level) FROM '$$PATH$$/2870.dat';

--
-- Data for Name: masakan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY masakan (id_masakan, nama_makanan, harga, status_masakan) FROM stdin;
\.
COPY masakan (id_masakan, nama_makanan, harga, status_masakan) FROM '$$PATH$$/2876.dat';

--
-- Data for Name: oorder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY oorder (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM stdin;
\.
COPY oorder (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM '$$PATH$$/2868.dat';

--
-- Data for Name: penumpang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY penumpang (id_penumpang, username, passsword, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telefone) FROM stdin;
\.
COPY penumpang (id_penumpang, username, passsword, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telefone) FROM '$$PATH$$/2878.dat';

--
-- Data for Name: transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM stdin;
\.
COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM '$$PATH$$/2862.dat';

--
-- Data for Name: uuser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY uuser (id_user, username, passsword, nama_user, id_level) FROM stdin;
\.
COPY uuser (id_user, username, passsword, nama_user, id_level) FROM '$$PATH$$/2865.dat';

--
-- Name: detail_order_id_detail_order_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('detail_order_id_detail_order_seq', 1, false);


--
-- Name: detail_order_id_masakan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('detail_order_id_masakan_seq', 1, false);


--
-- Name: detail_order_id_order_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('detail_order_id_order_seq', 1, false);


--
-- Name: levell_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('levell_id_level_seq', 1, false);


--
-- Name: masakan_id_masakan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('masakan_id_masakan_seq', 1, false);


--
-- Name: oorder_id_order_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('oorder_id_order_seq', 1, false);


--
-- Name: oorder_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('oorder_id_user_seq', 1, false);


--
-- Name: penumpang_id_penumpang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('penumpang_id_penumpang_seq', 1, false);


--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('transaksi_id_transaksi_seq', 1, false);


--
-- Name: uuser_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('uuser_id_level_seq', 1, false);


--
-- Name: uuser_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('uuser_id_user_seq', 1, false);


--
-- Name: detail_order detail_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_order
    ADD CONSTRAINT detail_order_pkey PRIMARY KEY (id_detail_order);


--
-- Name: levell levell_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY levell
    ADD CONSTRAINT levell_pkey PRIMARY KEY (id_level);


--
-- Name: masakan masakan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY masakan
    ADD CONSTRAINT masakan_pkey PRIMARY KEY (id_masakan);


--
-- Name: oorder oorder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY oorder
    ADD CONSTRAINT oorder_pkey PRIMARY KEY (id_order);


--
-- Name: penumpang penumpang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penumpang
    ADD CONSTRAINT penumpang_pkey PRIMARY KEY (id_penumpang);


--
-- Name: transaksi transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transaksi
    ADD CONSTRAINT transaksi_pkey PRIMARY KEY (id_transaksi);


--
-- Name: uuser uuser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY uuser
    ADD CONSTRAINT uuser_pkey PRIMARY KEY (id_user);


--
-- PostgreSQL database dump complete
--

